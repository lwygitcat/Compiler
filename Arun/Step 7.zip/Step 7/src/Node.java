public class Node
{
  public String content;
  public String type;
  
  public Node(String newContent, String newType)
  {
    this.content = newContent;
    this.type = newType;
  }
  
  public String toString()
  {

    return this.content;
  }
}
