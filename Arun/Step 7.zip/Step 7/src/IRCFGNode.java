import java.util.ArrayList;

public class IRCFGNode
{
  //private boolean isLeader;
  public String IRCode;
  public IRCFGNode pred;
  public IRCFGNode succ;
  public ArrayList<Integer> predecessors;
  public ArrayList<Integer> successors;
  public ArrayList<String> gen;
  public String kill;
  public int jumpNode;
  public Set<String> livein = new Hashset();
  public Set<String> out = new Hashset();
  
  public CFGNode(String IRCode)
  {
    this.IRCode = IRCode;
    predecessors = new ArrayList<Integer>();
	successors = new ArrayList<Integer>();
    gen = new ArrayList<Integer>();
	kill = null;
  }
 
  
  public String toString()
  {
    String s = "IRNode: hashCode details = , successors are:\n";
  }
  
}
