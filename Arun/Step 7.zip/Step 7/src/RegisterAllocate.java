import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class RegisterAllocate {
    public ArrayList<IRCFGNode> CFGList;
	private ArrayList<String> IRList;
	
	
	
	public RegisterAllocate(ArrayList<String> outputList){
	     this.IRList = outputList;
	}
	
	public void PredSucc() {
	     Map<String, Integer> labelMap = new HashMap<String, Integer>();
		 Map<String, Integer> jumpMap = new HashMap<String, Integer>();
		 String[] irElements;
		 int jmpIndex = 0;
		 IRCFGNode jmpNode = null;
		 /* use prev and curr to iterate through the list. similar to using
		    two pointers in traversing a linked list */
		 IRCFGNode prevNode = null;
		 IRCFGNode currNode = null;
		 for (int i=0; i<IR.size(); i++){   
		      IRCFGNode currNode = new IRCFGNode(IRList.get(i));
			  if((this.getJumpType(prevNode.IRCode) == 0) || (this.getJumpType(prev.IRCode) == 4)) continue;
			  /* for a normal instruction link directly */
              if(this.getJumpType(prevNode.IRCode) == 5) {
			      prevNode.successors.add(i);
				  currNode.predecessors.add(i-1);
			  }
			  /* UnConditional JUMP */
			  if(this.getJumpType(currNode.IRCode) == 1) {
			      String lbl = (irElements.split(" "))[1];
				  /* Check if we have already seen the definition of the label */
				  if(labelMap.contains(lbl)) {
				      jmpIndex = labelMap.get(lbl);
					  jmpNode = CFGList.get(jmpIndex);					  
				      currNode.successors.add(jmpIndex);
			          jmpNode.predecessors.add(i);
				  }
				  else {
				      jmpMap.put(lbl,i);
				  }
			  }
			  /* Conditional JUMPS */
			  if(this.getJumpType(currNode.IRCode) == 2) {
			      String lbl = (irElements.split(" "))[3];
				  /* Check if we have already seen the definition of the label */
				  if(labelMap.contains(lbl)) {
				      jmpIndex = labelMap.get(lbl);
					  jmpNode = CFGList.get(jmpIndex);					  
				      currNode.successors.add(jmpIndex);
			          jmpNode.predecessors.add(i);
				  }
				  else {
				      jmpMap.put(lbl,i);
				  }
			  }
			  /* LABEL */
			  if(this.getJumpType(currNode.IRCode) == 3) {
			      String lbl = (irElements.split(" "))[1];
				  /* Check if we have already seen the definition of the label */
				  if(labelMap.contains(lbl)) {
				      jmpIndex = labelMap.get(lbl);
					  jmpNode = CFGList.get(jmpIndex);					  
				      currNode.predecessors.add(jmpIndex);
			          jmpNode.successors.add(i);
				  }
				  else {
				      labelMap.put(lbl,i);
				  }
			  }
			  prevNode = currNode;
			  CFGList.add(currNode);
		    
		 }
		 
	}
	//JUMP - 1, LABEL - 2, Comparisons - 3
	public int getJumpType(String irCode) {
	     if( irCode != null && !irCode.isEmpty()) {
	        String[] irElements = irCode.split(" ");
	        if(irElements[0].equalsIgnoreCase("JUMP") return 1;
		    if(irElements[0].contains("NE") || irElements[0].contains("GE") || irElements[0].contains("LE")) return 2;
		    if(irElements[0].equalsIgnoreCase("LABEL") return 3;
			if(irElements[0].equalsIgnoreCase("RET") return 4;
		    else return 5;
		}
		else return 0;
	}
	
	public void GenKill() {
	        IRCFGNode cfgNode = null;
			String irCode = null;
			for (int i=0; i<CFGList.size(); i++){
                cfgNode = CFGList.get(i);
				irCode = cfgNode.IRCode;
				if(code.startsWith("ADD") || code.startsWith("SUB") || code.startsWith("MULT") || code.startsWith("DIV")){
				   node.gen[node.gens++] = part[1];
				   node.gen[node.gens++] = part[2];
				   node.kill = part[3];
				    node.kills ++;
			    }
            }			 
	}
    
	public void printCFG(

}